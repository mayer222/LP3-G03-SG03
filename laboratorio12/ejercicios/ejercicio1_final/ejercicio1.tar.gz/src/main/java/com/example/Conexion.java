package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Conexion {
    private Connection conn;
    public Connection getConn() {
        return conn;
    }

    public void setConn(Connection conn) {
        this.conn = conn;
    }
    private static final String DRIVER = "com.mysql.jdbc.Driver";
    private static final String URL = "jdbc:mysql://localhost:3306/users";
    private static final String USER = "jason";
    private static final String PASSWORD = "123546";

    Conexion() throws SQLException,ClassNotFoundException {
        try {
            System.setProperty(DRIVER, "");
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(URL,USER,PASSWORD);
            
            // Verifica si la tabla 'user' ya existe, y si no, la crea
            checkAndCreateTable();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Error al conectar a la base de datos");
        }
    }

    private void checkAndCreateTable() {
        try (Statement statement = conn.createStatement()) {
            // Verifica si la tabla 'user' ya existe
            if (!tableExists("user")) {
                // Crea la tabla 'user' si no existe
                createTableUser(statement);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void createTableUser(Statement statement) throws SQLException {
        // SQL para crear la tabla 'user'
        String createTableSQL = "CREATE TABLE user (" +
                "id INT AUTO_INCREMENT PRIMARY KEY," +
                "nombre VARCHAR(50) NOT NULL," +
                "apellido VARCHAR(50) NOT NULL)";
        // Ejecuta la instrucción SQL
        statement.executeUpdate(createTableSQL);
        System.out.println("Tabla 'user' creada con éxito.");
    }

    private boolean tableExists(String tableName) throws SQLException {
        // Verifica si la tabla ya existe en la base de datos
        try (java.sql.ResultSet rs = conn.getMetaData().getTables(null, null, tableName, null)) {
            return rs.next();
        }
    }
}